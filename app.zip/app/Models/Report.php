<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    protected $fillable = [
        'user_id',
        'file_path',
        'report_data',
    ];

    protected $casts = [
        'report_data' => 'array',
    ];
}
