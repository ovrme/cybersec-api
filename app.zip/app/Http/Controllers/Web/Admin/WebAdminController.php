<?php

namespace App\Http\Controllers\Web\Admin;

use App\Http\Controllers\Controller;
use App\Models\Lesson;
use App\Models\PhishingScanLog;
use App\Models\Quiz;
use App\Models\Report;
use App\Models\RiskScore;
use App\Models\User;
use Illuminate\Http\Request;

class WebAdminController extends Controller
{
    public function dashboard()
    {
        return view('admin.dashboard', [
            'totalUsers'   => User::count(),
            'totalLessons' => Lesson::count(),
            'totalQuizzes' => Quiz::count(),
            'totalScans'   => PhishingScanLog::count(),
            'totalReports' => Report::count(),
            'risk' => [
                'high'   => RiskScore::where('level', 'high')->count(),
                'medium' => RiskScore::where('level', 'medium')->count(),
                'low'    => RiskScore::where('level', 'low')->count(),
            ],
            'recentUsers' => User::latest()->take(6)->get(),
        ]);
    }

    /* ---------------- Users ---------------- */

    public function users()
    {
        $users = User::with('profile')->latest()->paginate(15);

        return view('admin.users', compact('users'));
    }

    public function updateUser(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $request->validate([
            'name'  => 'sometimes|string|max:100',
            'email' => 'sometimes|email|unique:users,email,' . $id,
            'role'  => 'sometimes|in:user,admin',
        ]);

        $user->update($request->only('name', 'email', 'role'));

        return back()->with('status', 'User updated.');
    }

    public function deleteUser($id)
    {
        // Prevent admins deleting themselves.
        if ((int) $id === auth()->id()) {
            return back()->withErrors(['user' => 'You cannot delete your own account.']);
        }

        User::findOrFail($id)->delete();

        return back()->with('status', 'User deleted.');
    }

    /* ---------------- Lessons ---------------- */

    public function lessons()
    {
        $lessons = Lesson::latest()->paginate(15);

        return view('admin.lessons', compact('lessons'));
    }

    public function storeLesson(Request $request)
    {
        $request->validate([
            'title'      => 'required|string|max:255',
            'content'    => 'required|string',
            'category'   => 'nullable|string|max:100',
            'difficulty' => 'required|in:beginner,intermediate,advanced',
        ]);

        Lesson::create($request->only('title', 'content', 'category', 'difficulty') + [
            'is_active'   => true,
            'order_index' => (int) (Lesson::max('order_index') + 1),
        ]);

        return back()->with('status', 'Lesson created.');
    }

    public function updateLesson(Request $request, $id)
    {
        $lesson = Lesson::findOrFail($id);

        $request->validate([
            'title'      => 'sometimes|string|max:255',
            'content'    => 'sometimes|string',
            'category'   => 'nullable|string|max:100',
            'difficulty' => 'sometimes|in:beginner,intermediate,advanced',
            'is_active'  => 'sometimes|boolean',
        ]);

        $lesson->update($request->only('title', 'content', 'category', 'difficulty', 'is_active'));

        return back()->with('status', 'Lesson updated.');
    }

    public function deleteLesson($id)
    {
        Lesson::findOrFail($id)->delete();

        return back()->with('status', 'Lesson deleted.');
    }

    /* ---------------- Quizzes ---------------- */

    public function quizzes()
    {
        $quizzes = Quiz::withCount('questions')->latest()->paginate(15);

        return view('admin.quizzes', compact('quizzes'));
    }

    public function deleteQuiz($id)
    {
        Quiz::findOrFail($id)->delete();

        return back()->with('status', 'Quiz deleted.');
    }

    /* ---------------- Logs & Reports ---------------- */

    public function scanLogs()
    {
        $logs = PhishingScanLog::with('user')->latest()->paginate(20);

        return view('admin.scan-logs', compact('logs'));
    }

    public function reports()
    {
        $reports = Report::with('user')->latest()->paginate(20);

        return view('admin.reports', compact('reports'));
    }
}
