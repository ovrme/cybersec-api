<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Lesson;
use App\Models\UserLessonProgress;
use Illuminate\Http\Request;

class WebLessonController extends Controller
{
    public function index(Request $request)
    {
        $userId = $request->user()->id;

        $query = Lesson::where('is_active', true);

        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }
        if ($request->filled('difficulty')) {
            $query->where('difficulty', $request->difficulty);
        }
        if ($request->filled('search')) {
            $term = $request->search;
            $query->where(fn ($q) => $q
                ->where('title', 'like', "%{$term}%")
                ->orWhere('content', 'like', "%{$term}%"));
        }

        $lessons = $query->orderBy('order_index')->get();

        $completedIds = UserLessonProgress::where('user_id', $userId)
            ->where('is_completed', true)->pluck('lesson_id')->all();

        $categories = Lesson::where('is_active', true)->whereNotNull('category')
            ->distinct()->pluck('category');

        // counts for chips
        $catCounts = Lesson::where('is_active', true)->whereNotNull('category')
            ->selectRaw('category, count(*) as c')->groupBy('category')
            ->pluck('c', 'category')->all();
        $totalAll     = Lesson::where('is_active', true)->count();
        $totalLessons = $totalAll;
        $doneCount    = count($completedIds);

        // resume strip: first active, not-yet-completed lesson
        $resumeLesson = Lesson::where('is_active', true)
            ->when($completedIds, fn ($q) => $q->whereNotIn('id', $completedIds))
            ->orderBy('order_index')->first();
        $resume = ($resumeLesson && $doneCount > 0) ? [
            'id'    => $resumeLesson->id,
            'title' => $resumeLesson->title,
            'pct'   => $totalLessons ? (int) round($doneCount / $totalLessons * 100) : 0,
        ] : null;

        return view('lessons.index', [
            'lessons'          => $lessons,
            'categories'       => $categories,
            'completedIds'     => $completedIds,
            'catCounts'        => $catCounts,
            'totalAll'         => $totalAll,
            'totalLessons'     => $totalLessons,
            'doneCount'        => $doneCount,
            'resume'           => $resume,
            'activeCategory'   => $request->category,
            'activeDifficulty' => $request->difficulty,
            'search'           => $request->search,
        ]);
    }

    public function show(Request $request, $id)
    {
        $lesson = Lesson::where('is_active', true)
            ->with('sections')
            ->findOrFail($id);

        $completed = UserLessonProgress::where('user_id', $request->user()->id)
            ->where('lesson_id', $id)->where('is_completed', true)->exists();

        return view('lessons.show', compact('lesson', 'completed'));
    }

    public function complete(Request $request, $id)
    {
        UserLessonProgress::updateOrCreate(
            ['user_id' => $request->user()->id, 'lesson_id' => $id],
            ['is_completed' => true, 'completed_at' => now()],
        );

        return back()->with('status', 'Lesson marked complete.');
    }
}
