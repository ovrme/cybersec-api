@extends('layouts.app')
@section('title', 'Leaderboard')

@section('content')
    <div class="mb-7">
        <h1 class="font-display text-3xl font-semibold">Leaderboard</h1>
        <p class="text-slate text-sm mt-1">Ranked by points — average quiz score plus lessons completed × 2.</p>
    </div>

    @if ($rows->isEmpty())
        <div class="bg-card border border-line rounded-2xl p-12 text-center card-shadow">
            <p class="text-slate">No ranked learners yet — take a quiz to appear here.</p>
        </div>
    @else
        <div class="bg-card border border-line rounded-2xl overflow-hidden card-shadow">
            <div class="grid grid-cols-[56px_1fr_auto_auto_auto] gap-3 px-6 py-3 border-b border-line text-xs text-slate uppercase tracking-wide">
                <span>Rank</span><span>Learner</span><span class="text-right">Quizzes</span><span class="text-right">Lessons</span><span class="text-right">Points</span>
            </div>
            @foreach ($rows as $row)
                @php
                    $isMe = $row['user_id'] === $myId;
                    $medal = ['1'=>'🥇','2'=>'🥈','3'=>'🥉'][$row['rank']] ?? null;
                @endphp
                <div class="grid grid-cols-[56px_1fr_auto_auto_auto] gap-3 px-6 py-3.5 items-center border-b border-line/60 last:border-0 {{ $isMe ? 'bg-tealsoft/50' : '' }}">
                    <span class="font-semibold {{ $row['rank'] <= 3 ? 'text-base' : 'text-slate' }}">{{ $medal ?? $row['rank'] }}</span>
                    <span class="text-sm {{ $isMe ? 'text-teal font-semibold' : '' }}">{{ $row['name'] }}{{ $isMe ? ' (you)' : '' }}</span>
                    <span class="text-sm text-slate text-right">{{ $row['quizzes_taken'] }}</span>
                    <span class="text-sm text-slate text-right">{{ $row['lessons_done'] }}</span>
                    <span class="text-sm font-semibold text-amber text-right">{{ $row['points'] }}</span>
                </div>
            @endforeach
        </div>
    @endif
@endsection
