@extends('layouts.app')
@section('title', 'Scanner')

@section('content')
    <div class="mb-7">
        <h1 class="font-display text-3xl font-semibold">Threat scanner</h1>
        <p class="text-slate text-sm mt-1">Analyze suspicious emails and URLs for phishing signals.</p>
    </div>

    <div class="grid lg:grid-cols-2 gap-5">
        <div class="bg-card border border-line rounded-2xl p-7 card-shadow">
            <h2 class="font-display text-lg font-semibold mb-1">Email scan</h2>
            <p class="text-slate text-sm mb-4">Paste suspicious email content.</p>
            <form method="POST" action="{{ route('scanner.email') }}">
                @csrf
                <textarea name="content" rows="6" required placeholder="Paste email body here…"
                          class="w-full bg-paper border border-line rounded-lg px-3.5 py-2.5 text-sm focus:border-teal focus:ring-1 focus:ring-teal focus:outline-none transition resize-none">{{ $type === 'email' ? ($input ?? '') : '' }}</textarea>
                <button class="mt-3 w-full bg-teal text-white font-medium py-2.5 rounded-lg hover:bg-teal/90 transition">Analyze email</button>
            </form>
        </div>

        <div class="bg-card border border-line rounded-2xl p-7 card-shadow">
            <h2 class="font-display text-lg font-semibold mb-1">URL scan</h2>
            <p class="text-slate text-sm mb-4">Enter a URL to inspect.</p>
            <form method="POST" action="{{ route('scanner.url') }}">
                @csrf
                <input type="text" name="url" required placeholder="https://example.com/login"
                       value="{{ $type === 'url' ? ($input ?? '') : '' }}"
                       class="w-full bg-paper border border-line rounded-lg px-3.5 py-2.5 text-sm focus:border-teal focus:ring-1 focus:ring-teal focus:outline-none transition">
                <button class="mt-3 w-full border border-teal text-teal font-medium py-2.5 rounded-lg hover:bg-tealsoft transition">Analyze URL</button>
            </form>
        </div>
    </div>

    @if ($result)
        @php $rc = ['high'=>'coral','medium'=>'amber','low'=>'teal'][$result['risk_level']] ?? 'slate'; @endphp
        <div class="bg-card border-2 border-{{ $rc }}/30 rounded-2xl p-7 mt-5 card-shadow">
            <div class="flex items-center justify-between mb-5">
                <div>
                    <p class="text-sm text-slate mb-1">Result · {{ $type }}</p>
                    <p class="font-display text-xl font-semibold text-{{ $rc }} capitalize">{{ $result['risk_level'] }} risk</p>
                </div>
                <div class="text-right">
                    <p class="font-display text-5xl font-semibold text-{{ $rc }}">{{ $result['risk_score'] }}</p>
                    <p class="text-xs text-slate">out of 100</p>
                </div>
            </div>
            @if (count($result['flags']) > 0)
                <p class="text-sm text-slate mb-2">Detected signals ({{ count($result['flags']) }})</p>
                <ul class="space-y-1.5">
                    @foreach ($result['flags'] as $flag)
                        <li class="flex gap-2 text-sm"><span class="text-{{ $rc }}">▸</span><span>{{ $flag }}</span></li>
                    @endforeach
                </ul>
            @else
                <p class="text-sm text-teal">No suspicious indicators detected.</p>
            @endif
        </div>
    @endif
@endsection
