@extends('layouts.app')
@section('title', $quiz->title)

@section('content')
    <a href="{{ route('quizzes.index') }}" class="text-sm text-slate hover:text-teal transition"> All quizzes</a>

    <div class="mt-4 mb-6 max-w-2xl">
        <h1 class="font-display text-2xl font-semibold">{{ $quiz->title }}</h1>
        <p class="text-slate text-sm mt-1">{{ $quiz->description }}</p>
    </div>

    <form method="POST" action="{{ route('quizzes.submit', $quiz->id) }}" class="space-y-4 max-w-2xl">
        @csrf
        @foreach ($quiz->questions as $i => $q)
            <div class="bg-card border border-line rounded-2xl p-6 card-shadow">
                <p class="text-xs text-teal font-medium mb-3">Question {{ $i + 1 }} of {{ $quiz->questions->count() }}</p>
                <p class="font-medium mb-4">{{ $q->question }}</p>
                <div class="space-y-2">
                    @foreach (['a','b','c','d'] as $opt)
                        @php $optText = $q->{"option_$opt"}; @endphp
                        @if ($optText)
                            <label class="flex items-center gap-3 border border-line rounded-lg px-4 py-2.5 cursor-pointer hover:border-teal transition has-[:checked]:border-teal has-[:checked]:bg-tealsoft">
                                <input type="radio" name="answers[{{ $q->id }}]" value="{{ $opt }}" required class="accent-teal">
                                <span class="text-xs text-slate uppercase font-medium">{{ $opt }}</span>
                                <span class="text-sm">{{ $optText }}</span>
                            </label>
                        @endif
                    @endforeach
                </div>
            </div>
        @endforeach
        <button class="w-full bg-teal text-white font-medium py-3 rounded-lg hover:bg-teal/90 transition">Submit answers</button>
    </form>
@endsection
