@extends('layouts.app')
@section('title', 'Results')

@php $rc = $passed ? 'teal' : 'amber'; @endphp

@section('content')
    <div class="max-w-2xl mx-auto">
        <div class="bg-card border-2 border-{{ $rc }}/30 rounded-2xl p-8 text-center mb-6 card-shadow">
            <p class="text-sm text-slate mb-2">{{ $quiz->title }}</p>
            <p class="font-display text-6xl font-semibold text-{{ $rc }}">{{ $percentage }}%</p>
            <p class="text-sm text-slate mt-2">{{ $score }} of {{ $total }} correct</p>
            <p class="text-sm text-{{ $rc }} font-medium mt-3">{{ $passed ? 'Passed — well done!' : 'Keep studying and try again.' }}</p>
        </div>

        <p class="text-sm text-slate mb-3">Review</p>
        <div class="space-y-3">
            @foreach ($results as $r)
                @php $ic = $r['is_correct'] ? 'teal' : 'coral'; @endphp
                <div class="bg-card border border-{{ $ic }}/25 rounded-2xl p-5 card-shadow">
                    <div class="flex items-start gap-2 mb-2">
                        <span class="text-{{ $ic }} text-sm font-bold">{{ $r['is_correct'] ? '✓' : '✗' }}</span>
                        <p class="font-medium text-sm">{{ $r['question'] }}</p>
                    </div>
                    <div class="text-xs ml-5 space-y-0.5">
                        <p class="text-slate">Your answer: <span class="text-{{ $ic }} uppercase font-medium">{{ $r['your_answer'] ?? '—' }}</span></p>
                        @unless ($r['is_correct'])
                            <p class="text-slate">Correct: <span class="text-teal uppercase font-medium">{{ $r['correct_answer'] }}</span></p>
                        @endunless
                    </div>
                    @if ($r['explanation'])
                        <p class="text-sm text-slate mt-3 ml-5 border-l-2 border-line pl-3">{{ $r['explanation'] }}</p>
                    @endif
                </div>
            @endforeach
        </div>

        <div class="flex gap-3 mt-6">
            <a href="{{ route('quizzes.show', $quiz->id) }}" class="flex-1 text-center border border-teal text-teal font-medium py-2.5 rounded-lg hover:bg-tealsoft transition">Retry</a>
            <a href="{{ route('quizzes.index') }}" class="flex-1 text-center border border-line text-slate py-2.5 rounded-lg hover:text-ink transition">All quizzes</a>
        </div>
    </div>
@endsection
