@extends('layouts.app')
@section('title', 'Quizzes')

@section('content')
    <div class="mb-7">
        <h1 class="font-display text-3xl font-semibold">Knowledge checks</h1>
        <p class="text-slate text-sm mt-1">Test what you've learned.</p>
    </div>

    <div class="grid md:grid-cols-2 gap-5">
        @foreach ($quizzes as $quiz)
            <a href="{{ route('quizzes.show', $quiz->id) }}" class="group bg-card border border-line rounded-2xl p-6 hover:border-teal transition block card-shadow">
                <div class="flex items-center justify-between mb-3">
                    <span class="text-xs font-medium text-teal">{{ $quiz->questions_count }} questions</span>
                    <span class="text-slate group-hover:text-teal transition"></span>
                </div>
                <h3 class="font-display text-lg font-semibold mb-1">{{ $quiz->title }}</h3>
                <p class="text-sm text-slate">{{ $quiz->description }}</p>
            </a>
        @endforeach
    </div>
@endsection
