@extends('layouts.app')
@section('title', 'Simulations')

@section('content')
    <div class="mb-7">
        <h1 class="font-display text-3xl font-semibold">Attack simulations</h1>
        <p class="text-slate text-sm mt-1">Practice spotting attacks in a safe environment.</p>
    </div>

    <div class="grid grid-cols-3 gap-5 mb-7">
        @php
            $cards = [
                ['Attempts', $stats['total'], 'slate'],
                ['Avoided', $stats['avoided'], 'teal'],
                ['Fell for', $stats['fell_for_it'], 'coral'],
            ];
        @endphp
        @foreach ($cards as [$label, $value, $color])
            <div class="bg-card border border-line rounded-2xl p-5 card-shadow text-center">
                <p class="text-sm text-slate mb-1">{{ $label }}</p>
                <p class="font-display text-3xl font-semibold text-{{ $color }}">{{ $value }}</p>
            </div>
        @endforeach
    </div>

    @if ($simulations->isEmpty())
        <div class="bg-card border border-line rounded-2xl p-12 text-center card-shadow">
            <p class="text-slate">No simulations available yet.</p>
        </div>
    @else
        <div class="grid md:grid-cols-2 gap-5">
            @foreach ($simulations as $sim)
                @php $typeLabel = ucwords(str_replace('_', ' ', $sim->type)); @endphp
                <a href="{{ route('simulations.show', $sim->id) }}" class="group bg-card border border-line rounded-2xl p-6 hover:border-teal transition block card-shadow">
                    <span class="text-xs font-medium uppercase tracking-wide px-2.5 py-1 rounded-full bg-paper border border-line text-slate">{{ $typeLabel }}</span>
                    <h3 class="font-display text-lg font-semibold group-hover:text-teal transition mt-3">{{ $sim->title }}</h3>
                </a>
            @endforeach
        </div>
    @endif
@endsection
