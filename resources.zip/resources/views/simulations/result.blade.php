@extends('layouts.app')
@section('title', 'Result')

@php $rc = $fellForIt ? 'coral' : 'teal'; @endphp

@section('content')
    <div class="max-w-2xl mx-auto">
        <div class="bg-card border-2 border-{{ $rc }}/30 rounded-2xl p-8 text-center card-shadow">
            <div class="text-4xl mb-3">{{ $fellForIt ? '⚠️' : '🛡️' }}</div>
            <p class="font-display text-xl font-semibold text-{{ $rc }} mb-2">{{ $message }}</p>
            <p class="text-sm text-slate">{{ $simulation->title }}</p>
        </div>

        <div class="bg-tealsoft border border-teal/20 rounded-2xl p-6 mt-5">
            <p class="text-sm text-teal font-medium mb-1">Takeaway</p>
            <p class="text-sm text-ink/90">{{ $tip }}</p>
        </div>

        <a href="{{ route('simulations.index') }}" class="block text-center mt-6 border border-line text-slate py-2.5 rounded-lg hover:text-ink transition">Back to simulations</a>
    </div>
@endsection
