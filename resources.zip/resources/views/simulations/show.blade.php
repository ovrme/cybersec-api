@extends('layouts.app')
@section('title', $simulation->title)

@section('content')
    <a href="{{ route('simulations.index') }}" class="text-sm text-slate hover:text-teal transition"> All simulations</a>

    <div class="max-w-2xl mt-4">
        @php $typeLabel = ucwords(str_replace('_', ' ', $simulation->type)); @endphp
        <span class="text-xs font-medium uppercase tracking-wide px-2.5 py-1 rounded-full bg-paper border border-line text-slate">{{ $typeLabel }}</span>
        <h1 class="font-display text-2xl font-semibold mt-3 mb-5">{{ $simulation->title }}</h1>

        {{-- The scenario, shown like a captured message --}}
        <div class="bg-card border border-line rounded-2xl p-6 card-shadow mb-6">
            <p class="text-xs text-slate uppercase tracking-wide mb-3">Simulated message</p>
            <div class="text-ink/90 leading-relaxed whitespace-pre-line border-l-2 border-amber pl-4">{{ $simulation->content }}</div>
        </div>

        <p class="font-medium mb-3">Would you have fallen for this?</p>
        <div class="flex gap-3">
            <form method="POST" action="{{ route('simulations.interact', $simulation->id) }}" class="flex-1">
                @csrf
                <input type="hidden" name="fell_for_it" value="0">
                <button class="w-full border border-teal text-teal font-medium py-2.5 rounded-lg hover:bg-tealsoft transition">No — I'd spot it</button>
            </form>
            <form method="POST" action="{{ route('simulations.interact', $simulation->id) }}" class="flex-1">
                @csrf
                <input type="hidden" name="fell_for_it" value="1">
                <button class="w-full border border-coral text-coral font-medium py-2.5 rounded-lg hover:bg-coral/10 transition">Yes — I might</button>
            </form>
        </div>
    </div>
@endsection
