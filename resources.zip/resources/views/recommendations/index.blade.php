@extends('layouts.app')
@section('title', 'Security Tips')

@php
    $lc = ['high'=>'coral','medium'=>'amber','low'=>'teal'][$level] ?? 'slate';
    $prioColor = ['critical'=>'coral','high'=>'amber','medium'=>'teal','low'=>'slate'];
@endphp

@section('content')
    <div class="mb-7">
        <h1 class="font-display text-3xl font-semibold">Security recommendations</h1>
        <p class="text-slate text-sm mt-1">
            Tailored to your current risk level:
            <span class="text-{{ $lc }} font-medium capitalize">{{ $level }}</span>
            @if ($score !== null) ({{ $score }}/100) @endif
        </p>
    </div>

    <div class="grid md:grid-cols-2 gap-5">
        @foreach ($tips as $tip)
            @php $pc = $prioColor[$tip['priority']] ?? 'slate'; @endphp
            <div class="bg-card border border-line rounded-2xl p-6 card-shadow">
                <div class="flex items-start justify-between gap-3 mb-2">
                    <h3 class="font-display text-lg font-semibold">{{ $tip['title'] }}</h3>
                    <span class="shrink-0 text-xs font-medium uppercase tracking-wide px-2.5 py-1 rounded-full bg-{{ $pc }}/10 text-{{ $pc }}">{{ $tip['priority'] }}</span>
                </div>
                <p class="text-sm text-slate leading-relaxed">{{ $tip['description'] }}</p>
            </div>
        @endforeach
    </div>
@endsection
