@extends('admin.layout')
@section('title', 'Quizzes')
@section('heading', 'Quiz management')

@section('content')
    <div class="bg-card border border-line rounded-2xl overflow-hidden card-shadow">
        <table class="w-full text-sm">
            <thead>
                <tr class="border-b border-line text-left text-slate text-xs uppercase tracking-wide">
                    <th class="px-5 py-3 font-medium">Title</th>
                    <th class="px-5 py-3 font-medium">Questions</th>
                    <th class="px-5 py-3 font-medium">Status</th>
                    <th class="px-5 py-3 font-medium text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-line">
                @foreach ($quizzes as $quiz)
                    <tr>
                        <td class="px-5 py-3 font-medium">{{ $quiz->title }}</td>
                        <td class="px-5 py-3 text-slate">{{ $quiz->questions_count }}</td>
                        <td class="px-5 py-3"><span class="text-xs {{ $quiz->is_active ? 'text-teal' : 'text-slate' }}">{{ $quiz->is_active ? 'Active' : 'Hidden' }}</span></td>
                        <td class="px-5 py-3 text-right">
                            <form method="POST" action="{{ route('admin.quizzes.delete', $quiz->id) }}"
                                  onsubmit="return confirm('Delete this quiz and all its questions?')" class="inline">
                                @csrf @method('DELETE')
                                <button class="text-xs border border-coral/40 text-coral px-2.5 py-1 rounded-lg hover:bg-coral/10 transition">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <div class="p-4">{{ $quizzes->links() }}</div>
    </div>
@endsection
