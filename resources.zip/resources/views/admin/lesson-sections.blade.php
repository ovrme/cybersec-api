@extends('admin.layout')
@section('title', 'Sections')
@section('heading', 'Sections — '.$lesson->title)

@section('content')
<div class="mb-5">
    <a href="{{ route('admin.lessons') }}" class="text-sm text-slate hover:text-teal transition">Back to lessons</a>
    <p class="text-slate text-sm mt-2">Each section is one "part" of the lesson. The <b>body</b> accepts HTML
        (&lt;p&gt;, &lt;ul&gt;&lt;li&gt;, &lt;strong&gt;, &lt;h3&gt;, &lt;code&gt;, &lt;blockquote&gt;, &lt;a&gt;).</p>
</div>

{{-- Existing sections --}}
@forelse ($lesson->sections as $section)
    <div class="bg-card border border-line rounded-2xl p-6 card-shadow mb-4">
        <div class="flex items-center justify-between mb-4">
            <span class="text-xs font-semibold uppercase tracking-wide text-teal">Part {{ $loop->iteration }}</span>
            <div class="flex items-center gap-3">
                <span class="text-xs text-slate">ID {{ $section->id }}</span>
                <form method="POST" action="{{ route('admin.lessons.sections.delete', $section->id) }}"
                      onsubmit="return confirm('Delete this section?')">
                    @csrf @method('DELETE')
                    <button class="text-xs border border-coral/40 text-coral px-2.5 py-1 rounded-lg hover:bg-coral/10 transition">Delete</button>
                </form>
            </div>
        </div>
        <form method="POST" action="{{ route('admin.lessons.sections.update', $section->id) }}" class="space-y-3">
            @csrf @method('PUT')
            <div class="grid md:grid-cols-[140px_1fr_90px] gap-3">
                <div>
                    <label class="block text-xs text-slate mb-1">Label</label>
                    <input name="label" value="{{ $section->label }}" placeholder="Read"
                           class="w-full bg-paper border border-line rounded-lg px-3 py-2 text-sm focus:border-teal focus:outline-none">
                </div>
                <div>
                    <label class="block text-xs text-slate mb-1">Title</label>
                    <input name="title" value="{{ $section->title }}" required
                           class="w-full bg-paper border border-line rounded-lg px-3 py-2 text-sm focus:border-teal focus:outline-none">
                </div>
                <div>
                    <label class="block text-xs text-slate mb-1">Order</label>
                    <input name="sort_order" type="number" value="{{ $section->sort_order }}" min="0"
                           class="w-full bg-paper border border-line rounded-lg px-3 py-2 text-sm focus:border-teal focus:outline-none">
                </div>
            </div>
            <div>
                <label class="block text-xs text-slate mb-1">Body (HTML)</label>
                <textarea name="body" rows="6" required
                          class="w-full bg-paper border border-line rounded-lg px-3 py-2 text-sm font-mono focus:border-teal focus:outline-none resize-y">{{ $section->body }}</textarea>
            </div>
            <button class="bg-teal text-white text-sm font-medium px-5 py-2 rounded-lg hover:bg-teal/90 transition">Save</button>
        </form>
    </div>
@empty
    <div class="bg-card border border-line rounded-2xl p-8 text-center card-shadow mb-4">
        <p class="text-slate text-sm">No sections yet. Add the first one below — until then, the lesson page falls back to its old content field.</p>
    </div>
@endforelse

{{-- Add new section --}}
<div class="bg-card border border-line rounded-2xl p-6 card-shadow mt-6">
    <h2 class="font-display text-lg font-semibold mb-4">Add a section</h2>
    <form method="POST" action="{{ route('admin.lessons.sections.store', $lesson->id) }}" class="space-y-3">
        @csrf
        <div class="grid md:grid-cols-[140px_1fr] gap-3">
            <div>
                <label class="block text-xs text-slate mb-1">Label</label>
                <input name="label" placeholder="Read"
                       class="w-full bg-paper border border-line rounded-lg px-3 py-2 text-sm focus:border-teal focus:outline-none">
            </div>
            <div>
                <label class="block text-xs text-slate mb-1">Title</label>
                <input name="title" required placeholder="Why phishing works"
                       class="w-full bg-paper border border-line rounded-lg px-3 py-2 text-sm focus:border-teal focus:outline-none">
            </div>
        </div>
        <div>
            <label class="block text-xs text-slate mb-1">Body (HTML)</label>
            <textarea name="body" rows="6" required placeholder="<p>Over <strong>90% of breaches</strong> start with a phishing email.</p>"
                      class="w-full bg-paper border border-line rounded-lg px-3 py-2 text-sm font-mono focus:border-teal focus:outline-none resize-y"></textarea>
        </div>
        <button class="bg-teal text-white text-sm font-medium px-5 py-2 rounded-lg hover:bg-teal/90 transition">Add section</button>
    </form>
</div>
@endsection
