<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Admin')  ·  SkillShield Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { theme: { extend: {
            fontFamily: { display:['Fraunces','serif'], sans:['Outfit','sans-serif'] },
            colors: { paper:'#f7f5f0', card:'#ffffff', ink:'#1d2520', slate:'#5a6760', teal:'#0f766e', tealsoft:'#d6ece9', coral:'#d1495b', amber:'#c9820a', line:'#e6e2d8' },
        }}}
    </script>
    <style>
        body { background:#f7f5f0; }
        .card-shadow { box-shadow: 0 1px 2px rgba(29,37,32,.04), 0 8px 24px -12px rgba(29,37,32,.12); }
        ::selection { background:#0f766e; color:#fff; }
    </style>
</head>
<body class="font-sans text-ink min-h-screen antialiased">
<div class="flex min-h-screen">
    {{-- Sidebar --}}
    <aside class="w-60 bg-ink text-paper/80 shrink-0 hidden md:flex flex-col">
        <div class="px-6 h-16 flex items-center gap-2.5 border-b border-white/10">
            <span class="w-7 h-7 rounded-lg bg-teal flex items-center justify-center text-white font-display font-bold text-sm">S</span>
            <span class="font-display font-semibold text-white">Admin</span>
        </div>
        <nav class="flex-1 p-3 space-y-1 text-sm">
            @php
                $items = [
                    'admin.dashboard' => 'Overview',
                    'admin.users'     => 'Users',
                    'admin.lessons'   => 'Lessons',
                    'admin.quizzes'   => 'Quizzes',
                    'admin.scan-logs' => 'Scan logs',
                    'admin.reports'   => 'Reports',
                ];
            @endphp
            @foreach ($items as $route => $label)
                <a href="{{ route($route) }}"
                   class="block px-3 py-2 rounded-lg transition {{ request()->routeIs($route) ? 'bg-teal text-white' : 'hover:bg-white/5 hover:text-white' }}">
                    {{ $label }}
                </a>
            @endforeach
        </nav>
        <div class="p-3 border-t border-white/10 space-y-1 text-sm">
            <a href="{{ route('dashboard') }}" class="block px-3 py-2 rounded-lg hover:bg-white/5 hover:text-white transition"> Back to app</a>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5 hover:text-coral transition">Sign out</button>
            </form>
        </div>
    </aside>

    {{-- Main --}}
    <div class="flex-1 min-w-0">
        <header class="bg-card border-b border-line h-16 flex items-center px-6">
            <h1 class="font-display text-lg font-semibold">@yield('heading', 'Admin')</h1>
        </header>

        @if (session('status'))
            <div class="px-6 mt-4">
                <div class="border border-teal/30 bg-tealsoft text-teal text-sm px-4 py-2.5 rounded-lg">{{ session('status') }}</div>
            </div>
        @endif
        @if ($errors->any())
            <div class="px-6 mt-4">
                <div class="border border-coral/30 bg-coral/10 text-coral text-sm px-4 py-2.5 rounded-lg">{{ $errors->first() }}</div>
            </div>
        @endif

        <main class="p-6">
            @yield('content')
        </main>
    </div>
</div>
</body>
</html>
