@extends('admin.layout')
@section('title', 'Lessons')
@section('heading', 'Lesson management')

@section('content')
    <div class="grid lg:grid-cols-3 gap-5">
        {{-- Create form --}}
        <div class="bg-card border border-line rounded-2xl p-6 card-shadow h-fit">
            <h2 class="font-display text-lg font-semibold mb-4">New lesson</h2>
            <form method="POST" action="{{ route('admin.lessons.store') }}" class="space-y-3">
                @csrf
                <input type="text" name="title" placeholder="Title" required
                       class="w-full bg-paper border border-line rounded-lg px-3 py-2 text-sm focus:border-teal focus:outline-none">
                <input type="text" name="category" placeholder="Category (optional)"
                       class="w-full bg-paper border border-line rounded-lg px-3 py-2 text-sm focus:border-teal focus:outline-none">
                <select name="difficulty" required class="w-full bg-paper border border-line rounded-lg px-3 py-2 text-sm focus:border-teal focus:outline-none">
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                </select>
                <textarea name="content" rows="5" placeholder="Lesson content" required
                          class="w-full bg-paper border border-line rounded-lg px-3 py-2 text-sm focus:border-teal focus:outline-none resize-none"></textarea>
                <button class="w-full bg-teal text-white font-medium py-2 rounded-lg hover:bg-teal/90 transition">Create lesson</button>
            </form>
        </div>

        {{-- List --}}
        <div class="lg:col-span-2 bg-card border border-line rounded-2xl overflow-hidden card-shadow">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b border-line text-left text-slate text-xs uppercase tracking-wide">
                        <th class="px-5 py-3 font-medium">Title</th>
                        <th class="px-5 py-3 font-medium">Level</th>
                        <th class="px-5 py-3 font-medium">Status</th>
                        <th class="px-5 py-3 font-medium text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-line">
                    @foreach ($lessons as $lesson)
                        @php $diff = ['beginner'=>'teal','intermediate'=>'amber','advanced'=>'coral'][$lesson->difficulty] ?? 'slate'; @endphp
                        <tr>
                            <td class="px-5 py-3 font-medium">{{ $lesson->title }}</td>
                            <td class="px-5 py-3"><span class="text-xs px-2 py-0.5 rounded-full bg-{{ $diff }}/10 text-{{ $diff }}">{{ $lesson->difficulty }}</span></td>
                            <td class="px-5 py-3">
                                <span class="text-xs {{ $lesson->is_active ? 'text-teal' : 'text-slate' }}">{{ $lesson->is_active ? 'Active' : 'Hidden' }}</span>
                            </td>
                            <td class="px-5 py-3">
                                <div class="flex items-center justify-end gap-2">
                                    <form method="POST" action="{{ route('admin.lessons.update', $lesson->id) }}">
                                        @csrf @method('PUT')
                                        <input type="hidden" name="is_active" value="{{ $lesson->is_active ? 0 : 1 }}">
                                        <button class="text-xs border border-line px-2.5 py-1 rounded-lg hover:border-teal hover:text-teal transition">{{ $lesson->is_active ? 'Hide' : 'Show' }}</button>
                                    </form>
                                    <form method="POST" action="{{ route('admin.lessons.delete', $lesson->id) }}"
                                          onsubmit="return confirm('Delete this lesson?')">
                                        @csrf @method('DELETE')
                                        <button class="text-xs border border-coral/40 text-coral px-2.5 py-1 rounded-lg hover:bg-coral/10 transition">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <div class="p-4">{{ $lessons->links() }}</div>
        </div>
    </div>
@endsection
