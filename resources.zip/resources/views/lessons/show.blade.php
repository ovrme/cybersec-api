@extends('layouts.app')
@section('title', $lesson->title)

@php
    $diff = ['beginner'=>'teal','intermediate'=>'amber','advanced'=>'coral'][$lesson->difficulty] ?? 'slate';

    // Prefer real DB sections. If a lesson has none yet, fall back to splitting
    // its old `content` field on blank lines so existing lessons still work.
    if ($lesson->sections && $lesson->sections->count()) {
        $parts = $lesson->sections->map(fn ($s) => [
            'label' => $s->label,
            'title' => $s->title,
            'body'  => $s->body,
            'html'  => true,
        ])->all();
    } else {
        $chunks = preg_split('/\n\s*\n/', trim((string) $lesson->content));
        $chunks = array_values(array_filter(array_map('trim', $chunks)));
        if (empty($chunks)) { $chunks = [(string) $lesson->content]; }
        $parts = array_map(fn ($c) => ['label'=>null, 'title'=>null, 'body'=>$c, 'html'=>false], $chunks);
    }
    $n = count($parts);
@endphp

@section('content')

{{-- ===== Hero ===== --}}
<div class="rounded-2xl mb-7 overflow-hidden" style="background:linear-gradient(135deg,#EAF5F1,#F4FAF8);border:1px solid #e6e2d8">
    <div class="p-7 md:p-9">
        <div class="flex items-end justify-between gap-6 flex-wrap">
            <div>
                <span class="inline-block text-[11px] font-bold tracking-wider rounded-full px-3 py-1 bg-{{ $diff }}/10 text-{{ $diff }} mb-3">
                    {{ strtoupper($lesson->difficulty) }}@if($lesson->category) · {{ strtoupper($lesson->category) }}@endif
                </span>
                <h1 class="font-display text-4xl font-semibold tracking-tight">{{ $lesson->title }}</h1>
                @if (! empty($lesson->summary))
                    <p class="text-slate mt-2 max-w-lg">{{ $lesson->summary }}</p>
                @endif
                <div class="flex flex-wrap gap-5 mt-4 text-sm text-slate">
                    @if ($lesson->duration_minutes)<span>⏱ <b class="text-ink">~{{ $lesson->duration_minutes }} min</b></span>@endif
                    @if ($lesson->points)<span>🏆 <b class="text-ink">+{{ $lesson->points }} pts</b></span>@endif
                    <span>📚 <b class="text-ink">{{ $n }} {{ Str::plural('part', $n) }}</b></span>
                </div>
            </div>
            <div x-data="{ p: {{ $completed ? 100 : 0 }} }" class="min-w-[200px]">
                <div class="flex items-center gap-2.5 text-sm font-semibold text-slate">
                    <div class="w-44 h-2 rounded-full overflow-hidden bg-white border border-line">
                        <div class="h-full bg-teal rounded-full transition-all" :style="`width:${p}%`"></div>
                    </div>
                    <span x-text="p + '%'"></span>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- ===== Layout: rail + sections ===== --}}
<div x-data="lessonReader({{ $n }}, {{ $completed ? 'true' : 'false' }})" class="grid lg:grid-cols-[240px_1fr] gap-7 items-start">

    <aside class="lg:sticky lg:top-20 bg-card border border-line rounded-2xl p-4 card-shadow">
        <h3 class="text-[11px] font-semibold tracking-[.1em] uppercase text-slate mb-3">Lesson outline</h3>
        @foreach ($parts as $i => $part)
            <button type="button" @click="go({{ $i }})"
                    class="flex items-center gap-2.5 w-full text-left px-2.5 py-2 rounded-lg text-sm font-medium transition"
                    :class="active === {{ $i }} ? 'bg-tealsoft text-teal font-semibold' : (done.includes({{ $i }}) ? 'text-ink' : 'text-slate hover:bg-paper')">
                <span class="w-5 h-5 rounded-full grid place-items-center text-[10px] shrink-0 border-2 transition"
                      :class="done.includes({{ $i }}) ? 'bg-teal border-teal text-white' : 'border-line'">
                    <span x-show="done.includes({{ $i }})">✓</span>
                </span>
                {{ $part['label'] ?? 'Part '.($i + 1) }}
            </button>
        @endforeach
        <button type="button" @click="go({{ $n }})"
                class="flex items-center gap-2.5 w-full text-left px-2.5 py-2 rounded-lg text-sm font-medium transition"
                :class="active === {{ $n }} ? 'bg-tealsoft text-teal font-semibold' : 'text-slate hover:bg-paper'">
            <span class="w-5 h-5 rounded-full grid place-items-center text-[10px] shrink-0 border-2"
                  :class="finished ? 'bg-teal border-teal text-white' : 'border-line'"><span x-show="finished">✓</span></span>
            Complete
        </button>
    </aside>

    <div>
        @foreach ($parts as $i => $part)
            <section x-show="active === {{ $i }}" x-transition
                     class="bg-card border border-line rounded-2xl card-shadow p-7 md:p-8 mb-5">
                <div class="text-xs font-semibold tracking-wide uppercase text-teal mb-2">
                    Part {{ $i + 1 }} of {{ $n }}@if ($part['label']) · {{ $part['label'] }}@endif
                </div>
                @if ($part['title'])
                    <h2 class="font-display text-2xl font-semibold mb-3">{{ $part['title'] }}</h2>
                @endif
                @if ($part['html'])
                    <div class="lesson-html">{!! $part['body'] !!}</div>
                @else
                    <div class="lesson-html whitespace-pre-line">{{ $part['body'] }}</div>
                @endif
                <div class="mt-7 flex items-center gap-3 flex-wrap">
                    <button type="button" @click="next({{ $i }})" class="inline-flex items-center gap-2 bg-teal text-white font-bold px-6 py-3 rounded-xl hover:bg-teal/90 transition">
                        {{ $i < $n - 1 ? 'Continue' : 'Finish lesson' }}
                    </button>
                    <span class="text-sm text-slate">Part {{ $i + 1 }} / {{ $n }}</span>
                </div>
            </section>
        @endforeach

        <section x-show="active === {{ $n }}" x-transition
                 class="bg-card border border-line rounded-2xl card-shadow p-9 text-center">
            <div class="w-16 h-16 rounded-2xl bg-tealsoft grid place-items-center mx-auto mb-4">
                <svg width="34" height="38" viewBox="0 0 22 24" fill="none"><path d="M11 1L21 5v6c0 6.1-4.3 10.6-10 12C5.3 21.6 1 17.1 1 11V5l10-4z" fill="#0f766e"/><path d="M7 11.5l3 3 5.5-5.5" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </div>
            <h2 class="font-display text-2xl font-semibold mb-2">Lesson complete — you're harder to fool</h2>
            <p class="text-slate max-w-md mx-auto mb-6">You've finished <b>{{ $lesson->title }}</b>. Mark it complete to update your progress.</p>
            @if ($completed)
                <p class="text-teal font-medium">✓ You've already completed this lesson.</p>
                <a href="{{ route('lessons.index') }}" class="inline-block mt-4 border border-teal text-teal font-semibold px-6 py-3 rounded-xl hover:bg-tealsoft transition">Back to lessons</a>
            @else
                <form method="POST" action="{{ route('lessons.complete', $lesson->id) }}" class="inline">@csrf
                    <button class="bg-teal text-white font-bold px-7 py-3 rounded-xl hover:bg-teal/90 transition">Mark as complete</button>
                </form>
                <a href="{{ route('lessons.index') }}" class="inline-block ml-2 border border-line text-slate font-semibold px-6 py-3 rounded-xl hover:border-teal hover:text-teal transition">Back to lessons</a>
            @endif
        </section>
    </div>
</div>

<style>
.lesson-html h2{font-family:'Fraunces',serif;font-size:1.3rem;font-weight:600;margin:1.3rem 0 .5rem}
.lesson-html h3{font-family:'Fraunces',serif;font-size:1.1rem;font-weight:600;margin:1.1rem 0 .4rem}
.lesson-html p{margin-bottom:.8rem;line-height:1.7;color:#3C4A46}
.lesson-html ul{margin:.5rem 0 1rem;padding-left:1.2rem;list-style:disc}
.lesson-html ol{margin:.5rem 0 1rem;padding-left:1.2rem;list-style:decimal}
.lesson-html li{margin-bottom:.35rem;color:#3C4A46}
.lesson-html strong{color:#1d2520;font-weight:600}
.lesson-html a{color:#0f766e;text-decoration:underline}
.lesson-html code{font-family:monospace;font-size:.85em;background:#FAE9E8;color:#B83A36;padding:2px 6px;border-radius:5px}
.lesson-html blockquote{border-left:3px solid #0f766e;background:#EAF5F1;padding:10px 14px;border-radius:0 8px 8px 0;margin:1rem 0;color:#1d2520}
</style>

<script>
function lessonReader(total, alreadyDone) {
    return {
        total,
        active: 0,
        done: alreadyDone ? Array.from({length: total}, (_, i) => i) : [],
        finished: alreadyDone,
        go(i) { this.active = i; window.scrollTo({top: 0, behavior: 'smooth'}); },
        next(i) {
            if (!this.done.includes(i)) this.done.push(i);
            if (i + 1 >= this.total) { this.finished = true; }
            this.active = i + 1;
            window.scrollTo({top: 180, behavior: 'smooth'});
        },
    }
}
</script>
@endsection
