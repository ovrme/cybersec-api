<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
    Schema::create('lessons', function (Blueprint $table) {
        $table->id();
        $table->string('title');
        $table->longText('content');
        $table->string('category')->nullable();
        $table->enum('difficulty', ['beginner','intermediate','advanced'])->default('beginner');
        $table->integer('order_index')->default(0);
        $table->boolean('is_active')->default(true);
        $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('lessons');
    }
};
